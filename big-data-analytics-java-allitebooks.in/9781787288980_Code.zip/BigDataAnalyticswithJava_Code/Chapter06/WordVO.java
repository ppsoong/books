package big_data_analytics_java.chp6;

public class WordVO {
	private String word;
	private long count;
	
	public WordVO() {
		
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}



	
	
}
