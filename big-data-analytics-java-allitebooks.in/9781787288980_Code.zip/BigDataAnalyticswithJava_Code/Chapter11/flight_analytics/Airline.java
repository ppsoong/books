package big_data_analytics_java.chp11.flight_analytics;

public class Airline {

	private Integer airlineId;
	private String airlineName;
	private String airlineCountry;
	
	public Airline() {
		
	}

	public Integer getAirlineId() {
		return airlineId;
	}

	public void setAirlineId(Integer airlineId) {
		this.airlineId = airlineId;
	}

	public String getAirlineName() {
		return airlineName;
	}

	public void setAirlineName(String airlineName) {
		this.airlineName = airlineName;
	}

	public String getAirlineCountry() {
		return airlineCountry;
	}

	public void setAirlineCountry(String airlineCountry) {
		this.airlineCountry = airlineCountry;
	}
	
	
}
