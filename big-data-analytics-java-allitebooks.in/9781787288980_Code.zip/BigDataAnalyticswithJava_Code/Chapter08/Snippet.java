package chp8;

public class Snippet {
	Count of loans by grade.
}

